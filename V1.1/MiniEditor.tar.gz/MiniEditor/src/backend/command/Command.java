package backend.command;

public interface Command {
	
	public void execute();
}
