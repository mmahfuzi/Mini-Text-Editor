package backend.receiver;

import backend.exceptions.InvalidSelectionException;

public class MiniEditorImpl implements MiniEditor{

	private int selectionStart;
	private int selectionEnd;
	private String bufferContent;
	private Clipboard clipboard;
	
	public MiniEditorImpl() {
		bufferContent = "";
		clipboard = new Clipboard();
	}
	
	@Override
	public String getBuffer() {
		return bufferContent;
	}

	@Override
	public String getSelection() {
		return bufferContent.substring(selectionStart, selectionEnd) + "[" + selectionStart + "," + selectionEnd + "]";
	}

	@Override
	public String getClipboard() {
		return clipboard.getContents();
	}

	@Override
	public void editorInsert(String substring) {
		bufferContent = bufferContent.substring(0, selectionStart) + substring + bufferContent.substring(selectionEnd);
		selectionStart = selectionEnd = selectionStart + substring.length();
	}

	@Override
	public void editorSelect(int start, int stop) {
		try {
			if((start >= 0 && start <= bufferContent.length()) && (stop >=0 && stop  <= bufferContent.length()) && (stop >= start)) {
				selectionStart = start;
				selectionEnd = stop;
			} else {
				throw new InvalidSelectionException();
			}
		} catch(InvalidSelectionException ise) {
			System.out.println("ERROR! Invalid selection.");
		}
	}

	@Override
	public void editorCopy() {
		if(selectionStart != selectionEnd)
			clipboard.setContents(bufferContent.substring(selectionStart, selectionEnd));
	}

	@Override
	public void editorCut() {
		editorCopy();
		editorDelete();
	}

	@Override
	public void editorPaste() {
		if(!clipboard.isEmpty()) {
			bufferContent = bufferContent.substring(0, selectionStart) + clipboard.getContents() + bufferContent.substring(selectionEnd);
			selectionStart = selectionEnd = selectionStart + clipboard.getContents().length();
		}
	}
	
	@Override
	public void editorDelete() {
		bufferContent = bufferContent.substring(0, selectionStart) + bufferContent.substring(selectionEnd);
		selectionEnd = selectionStart;
	}
}
